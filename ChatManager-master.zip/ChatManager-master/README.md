# ChatManager
The most complete plugin for taking full control over your chat.
